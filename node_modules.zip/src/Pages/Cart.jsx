import React from 'react'
import CartItems from '../Components/CartItems.jsx/CartItems'


const Cart = () => {
  return (
    <div>
    <CartItems></CartItems>
      
    </div>
  )
}

export default Cart
